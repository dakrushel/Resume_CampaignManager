import { useState, useEffect } from "react";
import { fetchCharactersByCampaign } from "./characterAPIs/pcMongoAPIs";
import CharacterDisplay from "./characterdisplay";
import PropTypes from "prop-types";

const CharacterList = ({ campaignID }) => {
  const [characters, setCharacters] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showCharacters, setShowCharacters] = useState(false); // Toggle for displaying character list

  useEffect(() => {
    const loadCharacters = async () => {
      try {
        const data = await fetchCharactersByCampaign(campaignID);
        setCharacters(data);
      } catch (err) {
        setError("Failed to fetch characters.");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    loadCharacters();
  }, [campaignID]);

  return (
    <div className="p-4 bg-white rounded-lg shadow-md">
      <button
        onClick={() => setShowCharacters(!showCharacters)}
        className="mt-2 text-blue-600 underline"
      >
        Player Characters {showCharacters ? "▲" : "▼"}
      </button>

      {showCharacters && (
        <>
          {loading ? (
            <p>Loading characters...</p>
          ) : error ? (
            <p className="text-red-600">{error}</p>
          ) : characters.length === 0 ? (
            <p>No characters found for this campaign.</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
              {characters.map((char) => (
                <CharacterDisplay key={char._id} character={char} />
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
};

CharacterList.propTypes = {
  campaignID: PropTypes.string.isRequired,
};

export default CharacterList;
