import { getAllCharacters, getCharacterById, getCharactersByCampaignID, addCharacter, updateCharacter, deleteCharacter } from "../../../../server/models/characterModel";

// Fetch all characters
export const fetchAllCharacters = async () => {
    try {
        return await getAllCharacters();
    } catch (error) {
        console.error("Error fetching all characters:", error);
        throw error;
    }
};

// Fetch a character by ID
export const fetchCharacterById = async (id) => {
    try {
        return await getCharacterById(id);
    } catch (error) {
        console.error("Error fetching character by ID:", error);
        throw error;
    }
};

// Fetch characters by campaign ID
export const fetchCharactersByCampaign = async (campaignID) => {
    try {
        return await getCharactersByCampaignID(campaignID);
    } catch (error) {
        console.error("Error fetching characters by campaign ID:", error);
        throw error;
    }
};

// Add a new character
export const createCharacter = async (characterData) => {
    try {
        return await addCharacter(characterData);
    } catch (error) {
        console.error("Error adding new character:", error);
        throw error;
    }
};

// Update a character
export const modifyCharacter = async (id, characterData) => {
    try {
        return await updateCharacter(id, characterData);
    } catch (error) {
        console.error("Error updating character:", error);
        throw error;
    }
};

// Delete a character
export const removeCharacter = async (id) => {
    try {
        return await deleteCharacter(id);
    } catch (error) {
        console.error("Error deleting character:", error);
        throw error;
    }
};
